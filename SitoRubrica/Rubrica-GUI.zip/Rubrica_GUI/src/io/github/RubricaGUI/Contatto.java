
package io.github.RubricaGUI;


public class Contatto {
    private String nome;
    private String cognome;
    private String recapito;
    private String email;

    public Contatto(String nome, String cognome, String recapito, String email) {
        this.nome = nome;
        this.cognome = cognome;
        this.recapito = recapito;
        this.email = email;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCognome() {
        return cognome;
    }

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    public String getRecapito() {
        return recapito;
    }

    public void setRecapito(String recapito) {
        this.recapito = recapito;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
}
