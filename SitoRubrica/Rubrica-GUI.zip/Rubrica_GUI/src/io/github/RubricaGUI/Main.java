package io.github.RubricaGUI;
import com.formdev.flatlaf.FlatDarkLaf;
import io.github.RubricaGUI.controller.AddContattoController;
import io.github.RubricaGUI.controller.ControllerView;
import io.github.RubricaGUI.controller.DeleteContattoController;
import io.github.RubricaGUI.controller.EliminaContattoController;
import io.github.RubricaGUI.controller.ModificaContattoController;
import io.github.RubricaGUI.model.Model;
import io.github.RubricaGUI.view.FrmPrincipale;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public class Main {

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {

                try {
                    UIManager.setLookAndFeel(new FlatDarkLaf());
                } catch (UnsupportedLookAndFeelException e) {
                    e.printStackTrace();
                }

                FrmPrincipale view = new FrmPrincipale();
                Model model = new Model();

                //creiamo gli oggetti dei controller
                AddContattoController controller = new AddContattoController(view, model);
                EliminaContattoController eliminaContattoController = new EliminaContattoController(view, model);
                DeleteContattoController controllerDelete = new DeleteContattoController(view, model);
                ModificaContattoController modificaContattoController = new ModificaContattoController(view, model);
                ControllerView controllerView = new ControllerView(view, model);

                view.setControllerView(controllerView);
                view.setAddContattoController(controller);
                view.setDeleteContattoController(controllerDelete);
                view.setEliminaContattoController(eliminaContattoController);
                view.setModificaContattoController(modificaContattoController);

                view.setVisible(true);

            }

        });
    }
}
