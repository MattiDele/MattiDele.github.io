package io.github.RubricaGUI.controller;

import io.github.RubricaGUI.Contatto;
import io.github.RubricaGUI.model.Model;
import io.github.RubricaGUI.model.ModelTabella;
import io.github.RubricaGUI.view.AddContattoDialog;
import io.github.RubricaGUI.view.ContattoListener;
import io.github.RubricaGUI.view.FrmPrincipale;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

public class AddContattoController {

    private FrmPrincipale view;
    private AddContattoDialog dialog;
    private Model model;

    public AddContattoController(FrmPrincipale view, Model model) {
        this.view = view;
        this.model = model;
    }

    public void addNuovoContatto() {
        dialog = new AddContattoDialog(view, true);
        dialog.addContattoListener(new ContattoListener() {
            @Override
            public void contattoActionPerfomed() {
                Contatto c = dialog.getContatto();
                if (isEsistente(c.getNome(), c.getCognome()) == false) {
                    if (isNumeroValido(c.getRecapito()) == true) {
                        if (!isEmailValid(c.getEmail())) {
                            c.setEmail("N/D");
                        }
                        model.aggiungiContatto(c);
                        addContattoScrollPaneTabella(c);
                        dialog.dispose();
                        JOptionPane.showMessageDialog(null,
                                "CONTATTO AGGIUNTO",
                                "Aggiungi Contatto",
                                JOptionPane.INFORMATION_MESSAGE);
                        view.getControllerView().counterContattiRegistrati();

                    }

                }

            }
        });
        dialog.setVisible(true);
    }

    public boolean isEsistente(String nome, String cognome) {

        if (nome.isEmpty() || cognome.isEmpty()) {
            dialog.dispose();
            JOptionPane.showMessageDialog(null,
                    "INSERIRE NOME E COGNOME DEL CONTATTO",
                    "ERRORE",
                    JOptionPane.ERROR_MESSAGE);
            return true;
        } else {
            for (int i = 0; i < model.getRubrica().size(); i++) { //sostituire con for
                if (nome.equalsIgnoreCase(model.getRubrica().get(i).getNome())
                        && cognome.equalsIgnoreCase(model.getRubrica().get(i).getCognome())) {
                    dialog.dispose();
                    JOptionPane.showMessageDialog(null,
                            "CONTATTO GIA' ESISTENTE!",
                            "ERRORE",
                            JOptionPane.ERROR_MESSAGE);
                    return true;
                }

            }
        }

        return false;
    }

    public static boolean isEmailValid(String email) {
        String regex = "^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^-]+(?:.[a-zA-Z0-9_!#$%&'*+/=?`{|}~^-]+)*@[a-zA-Z0-9-]+(?:.[a-zA-Z0-9-]+)*$";
        Pattern p = Pattern.compile(regex);
        return p.matcher(email).matches();
    }

    public boolean isNumeroValido(String telefono) {
        if (!telefono.matches("[0-9]+")) {
            dialog.dispose();
            JOptionPane.showMessageDialog(null,
                    "RECAPITO NON VALIDO!",
                    "ERRORE",
                    JOptionPane.ERROR_MESSAGE);
            dialog.setVisible(true);
            return false;
        } else {
            return true;
        }
    }

    public void addContattoScrollPaneTabella(Contatto contatto) {
        ModelTabella tableModel = (ModelTabella) view.getTblContatti().getModel();
        tableModel.aggiungiContatto(contatto);
    }

}
