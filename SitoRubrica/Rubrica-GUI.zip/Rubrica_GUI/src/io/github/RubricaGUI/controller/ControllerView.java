package io.github.RubricaGUI.controller;

import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatLightLaf;
import io.github.RubricaGUI.Contatto;
import io.github.RubricaGUI.model.Model;
import io.github.RubricaGUI.model.ModelTabella;
import io.github.RubricaGUI.view.FrmPrincipale;
import java.awt.Component;
import java.awt.Container;
import java.awt.Window;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public class ControllerView {

    private FrmPrincipale view;
    ModelTabella tableModel;
    Model model;
    
    public ControllerView(FrmPrincipale view, Model model) {
        this.model = model;
        this.view = view;
        model.caricaContattiArray();
        counterContattiRegistrati();
        aggiornaTabella();
    }

    public void counterContattiRegistrati() {
        view.getTxtContattiRegistrati().setText(model.getRubrica().size() + "");
    }

    public void aggiornaTabella() {
        tableModel = (ModelTabella) view.getTblContatti().getModel();
        for (Contatto contatto : model.getRubrica()) {
            tableModel.aggiungiContatto(contatto);
        }
    }

    public void temaFlatLafLight() {
        try {

            UIManager.setLookAndFeel(new FlatLightLaf()); 
            
            SwingUtilities.invokeLater(() -> {
                
                for (Window window : Window.getWindows()) {
                    SwingUtilities.updateComponentTreeUI(window); 
                }
                
                resetComponentStyles(view);

                view.repaint();  // Ridisegna la finestras

            });
        } catch (UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }

    }
    
    public void temaFlatLafDark() {
        try {

            UIManager.setLookAndFeel(new FlatDarkLaf()); 

            
            SwingUtilities.invokeLater(() -> {
                for (Window window : Window.getWindows()) {
                    SwingUtilities.updateComponentTreeUI(window); 
                }

                
                resetComponentStyles(view);

                view.repaint();  

            });
        } catch (UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }

    }
    
    private void resetComponentStyles(Container container) {
    for (Component comp : container.getComponents()) {
        if (comp instanceof JButton) {
            JButton button = (JButton) comp;
            button.setBackground(null);  
            button.setBorder(null);
            button.setOpaque(false);     
        }
        if (comp instanceof JPanel || comp instanceof JScrollPane) {
            comp.setBackground(null);    
        }
        if (comp instanceof JTextField) {
            comp.setBackground(null);    
        }
        if (comp instanceof Container) {
            resetComponentStyles((Container) comp);  
        }
    }
}
}
