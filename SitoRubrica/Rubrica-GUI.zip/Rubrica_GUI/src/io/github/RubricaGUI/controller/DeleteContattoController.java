package io.github.RubricaGUI.controller;

import io.github.RubricaGUI.Contatto;
import io.github.RubricaGUI.model.Model;
import io.github.RubricaGUI.model.ModelTabella;
import io.github.RubricaGUI.view.ContattoListener;
import io.github.RubricaGUI.view.DeleteContattoDialog;
import io.github.RubricaGUI.view.FrmPrincipale;
import javax.swing.JOptionPane;
import javax.swing.JTable;

public class DeleteContattoController {

    private FrmPrincipale view;
    private DeleteContattoDialog dialog;
    private Model model;
    private ModelTabella modelTabella;

    public DeleteContattoController(FrmPrincipale view, Model model) {
        this.view = view;
        this.model = model;
    }

    public void deleteContatto() {
        dialog = new DeleteContattoDialog(view, true);
        dialog.setTitle("Elimina Contatto");
        if (model.getRubrica().isEmpty()) {
            JOptionPane.showMessageDialog(null,
                    "RUBRICA VUOTA",
                    "ERRORE",
                    JOptionPane.ERROR_MESSAGE);
        } else {
            dialog.addContattoListener(new ContattoListener() {
                @Override
                public void contattoActionPerfomed() {
                    Contatto c = dialog.getContatto();
                    isTheContact();
                    dialog.dispose();
                    aggiornaTabella(view.getTblContatti());
                    JOptionPane.showMessageDialog(null,
                            "CONTATTO RIMOSSO!",
                            "Elimina Contatto",
                            JOptionPane.INFORMATION_MESSAGE);
                    view.getControllerView().counterContattiRegistrati();
                }
            });
            dialog.setVisible(true);

        }

    }

    //Si occupa di verificare che il contatto passato sia corretto e lo elimina dall'arrayList e tabella
    public void isTheContact() {
        Contatto c = dialog.getContatto();
        for (int i = 0; i < model.getRubrica().size(); i++) {
            if (c.getNome().equals(model.getRubrica().get(i).getNome())
                    && c.getCognome().equals(model.getRubrica().get(i).getCognome())) {
                model.removeContatto(c, view.getTblContatti());
                break;
            } else {
                dialog.dispose();
                JOptionPane.showMessageDialog(null,
                        "CONTATTO NON ESISTENTE",
                        "ERRORE",
                        JOptionPane.ERROR_MESSAGE);
                dialog.setVisible(true);
            }
        }
    }
    
    public void aggiornaTabella(JTable table) {
        ModelTabella tableModel = (ModelTabella)table.getModel();
        
        tableModel.setRowCount(0);//cancella tutte le righe presenti nella tabella

        
        for (Contatto contatto : model.getRubrica()) {
            tableModel.aggiungiContatto(contatto); //Dopo aver azzerato le righe della tabella, riaggiungiamo tutti i contatti presenti nell' arrayList    
        }
    }
}
