package io.github.RubricaGUI.controller;

import io.github.RubricaGUI.Contatto;
import io.github.RubricaGUI.model.Model;
import io.github.RubricaGUI.model.ModelTabella;
import io.github.RubricaGUI.view.ContattoListener;
import io.github.RubricaGUI.view.EliminaContattoDialog;
import io.github.RubricaGUI.view.FrmPrincipale;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class EliminaContattoController {

    private FrmPrincipale view;
    private EliminaContattoDialog dialog;
    private Model model;
    private ModelTabella modelTabella;

    public EliminaContattoController(FrmPrincipale view, Model model) {
        this.view = view;
        this.model = model;
    }

    public void eliminaContatto() {
        dialog = new EliminaContattoDialog(view, true);
        modelTabella = (ModelTabella) dialog.getTblEliminaContatti().getModel();
        //aggiungiamo i contati creati alla tabella per elimare i contatti
        for (Contatto contatto : model.getRubrica()) {
            modelTabella.aggiungiContatto(contatto);
        }
        //richiamiamo il metodo per selezionare una riga della tabella e riempire le textField con gli appositi dati del contatto
        selezioneRigaTabella();

        dialog.addContattoListener(new ContattoListener() {
            @Override
            public void contattoActionPerfomed() {
                int selectedRow = dialog.getTblEliminaContatti().getSelectedRow();
                if (selectedRow != -1) {
                    Contatto contattoDaEliminare = model.getRubrica().get(selectedRow);
                    if (contattoDaEliminare != null) {
                        //rimuoviamo il contatto dalla rubrica e talla tabella della finestra principale
                        model.removeContatto(contattoDaEliminare, view.getTblContatti());
                        model.scritturaFile();
                        //ripuliamo le txtField
                        dialog.clearTxt();
                        aggiornaTabella(view.getTblContatti());
                        aggiornaTabella(dialog.getTblEliminaContatti());
                        JOptionPane.showMessageDialog(null,
                        "CONTATTO RIMOSSO!",
                        "Elimina Contatto",
                        JOptionPane.INFORMATION_MESSAGE);
                        view.getControllerView().counterContattiRegistrati();
                    }

                }

            }

        });
        model.scritturaFile();
        dialog.setVisible(true);
    }

    public void selezioneRigaTabella() {
        //prendiamo il modello della tabella e gli assegnamo un ascoltatore di tipoListSelectionListener
        //l'implementazione di quest'ultimo, avviene attraverso la classe anonima
        dialog.getTblEliminaContatti().getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent event) {
                //assegnao a una variabile intera, il numero di riga seleziona nella tabella (Le righe partono da 0)
                int rigaSelezionata = dialog.getTblEliminaContatti().getSelectedRow();
                // il metodo getSelectedRow(); restituisce un intero, che indica la riga selezionata, altrimenti restituisce -1
                if (rigaSelezionata != -1) {
                    //settiamo il testo delle varie txtField, co gli appositi dati del contatto
                    Contatto contattoSelezionato = model.getRubrica().get(rigaSelezionata);
                    dialog.getTxtNome().setText(contattoSelezionato.getNome());
                    dialog.getTxtCognome().setText(contattoSelezionato.getCognome());
                    dialog.getTxtRecapito().setText(contattoSelezionato.getRecapito());
                    dialog.getTxtEmail().setText(contattoSelezionato.getEmail());
                }
            }
        });
    }

    public void aggiornaTabella(JTable table) {
        ModelTabella tableModel = (ModelTabella)table.getModel();
        
        tableModel.setRowCount(0);//cancella tutte le righe presenti nella tabella

        
        for (Contatto contatto : model.getRubrica()) {
            tableModel.aggiungiContatto(contatto); //Dopo aver azzerato le righe della tabella, riaggiungiamo tutti i contatti presenti nell' arrayList    
        }
    }
}
