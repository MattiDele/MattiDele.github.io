package io.github.RubricaGUI.controller;

import io.github.RubricaGUI.Contatto;
import io.github.RubricaGUI.model.Model;
import io.github.RubricaGUI.model.ModelTabella;
import io.github.RubricaGUI.view.ContattoListener;
import io.github.RubricaGUI.view.FrmPrincipale;
import io.github.RubricaGUI.view.ModificaContattoDialog;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class ModificaContattoController {

    FrmPrincipale view = new FrmPrincipale();
    Model model = new Model();
    ModelTabella modelTabella;
    ModificaContattoDialog dialog;
    EliminaContattoController controllerEliminaContatto;

    public ModificaContattoController(FrmPrincipale view, Model model) {
        this.view = view;
        this.model = model;
    }

    public void modificaContatto() {
        dialog = new ModificaContattoDialog(view, true);
        modelTabella = (ModelTabella) dialog.getTblModificaContatti().getModel();
        for (Contatto contatto : model.getRubrica()) {
            modelTabella.aggiungiContatto(contatto);
        }
        selezioneRigaTabella();
        dialog.addContattoListener(new ContattoListener() {
            @Override
            public void contattoActionPerfomed() {
                int rigaSelezionata = dialog.getTblModificaContatti().getSelectedRow();
                Contatto contattoDaModificare = model.getRubrica().get(rigaSelezionata);

                String nome = dialog.getTxtNome().getText();
                String cognome = dialog.getTxtCognome().getText();
                String recapito = dialog.getTxtRecapito().getText();
                String email = dialog.getTxtEmail().getText();

                contattoDaModificare.setNome(nome);
                contattoDaModificare.setCognome(cognome);
                contattoDaModificare.setRecapito(recapito);
                contattoDaModificare.setEmail(email);

                //Aggiorniamo le tabelle della JDialog e della view peincipale
                modificheTabelle(contattoDaModificare, rigaSelezionata);
                model.scritturaFile();
                JOptionPane.showMessageDialog(null,
                        "CONTATTO MODIFICATO!",
                        "Modifica Contatto",
                        JOptionPane.INFORMATION_MESSAGE);
            }

        });
        dialog.setVisible(true);

    }

    public void selezioneRigaTabella() {
        //prendiamo il modello della tabella e gli assegnamo un ascoltatore di tipoListSelectionListener
        //l'implementazione di quest'ultimo, avviene attraverso la classe anonima
        dialog.getTblModificaContatti().getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent event) {
                //assegnao a una variabile intera, il numero di riga seleziona nella tabella (Le righe partono da 0)
                int rigaSelezionata = dialog.getTblModificaContatti().getSelectedRow();
                // il metodo getSelectedRow(); restituisce un intero, che indica la riga selezionata, altrimenti restituisce -1
                if (rigaSelezionata != -1) {
                    //settiamo il testo delle varie txtField, co gli appositi dati del contatto
                    Contatto contattoSelezionato = model.getRubrica().get(rigaSelezionata);
                    dialog.getTxtNome().setText(contattoSelezionato.getNome());
                    dialog.getTxtCognome().setText(contattoSelezionato.getCognome());
                    dialog.getTxtRecapito().setText(contattoSelezionato.getRecapito());
                    dialog.getTxtEmail().setText(contattoSelezionato.getEmail());
                }
            }
        });
    }
    
    public void modificheTabelle(Contatto contattoDaModificare, int rigaSelezionata){
                    // Aggiorniamo la tabella della JDialog EliminaContattoDialog
                    modelTabella.setValueAt(contattoDaModificare.getNome(), rigaSelezionata, 0);
                    modelTabella.setValueAt(contattoDaModificare.getCognome(), rigaSelezionata, 1);
                    modelTabella.setValueAt(contattoDaModificare.getRecapito(), rigaSelezionata, 2);
                    modelTabella.setValueAt(contattoDaModificare.getEmail(), rigaSelezionata, 3);
                    
                    // Aggiorniamo la tabella della view Principale FrmPrincipale
                    view.getTblContatti().setValueAt(contattoDaModificare.getNome(), rigaSelezionata, 0);
                    view.getTblContatti().setValueAt(contattoDaModificare.getCognome(), rigaSelezionata, 1);
                    view.getTblContatti().setValueAt(contattoDaModificare.getRecapito(), rigaSelezionata, 2);
                    view.getTblContatti().setValueAt(contattoDaModificare.getEmail(), rigaSelezionata, 3);
    }
    
        public void aggiornaTabella(JTable table) {
        ModelTabella tableModel = (ModelTabella)table.getModel();
        
        tableModel.setRowCount(0);//cancella tutte le righe presenti nella tabella

        
        for (Contatto contatto : model.getRubrica()) {
            tableModel.aggiungiContatto(contatto); //Dopo aver azzerato le righe della tabella, riaggiungiamo tutti i contatti presenti nell' arrayList    
        }
    }
}
