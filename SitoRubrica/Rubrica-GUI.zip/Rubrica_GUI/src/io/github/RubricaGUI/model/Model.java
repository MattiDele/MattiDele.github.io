package io.github.RubricaGUI.model;

import io.github.RubricaGUI.Contatto;
import io.github.RubricaGUI.controller.ControllerView;
import java.io.*;
import java.util.ArrayList;
import java.util.StringTokenizer;
import javax.swing.JTable;

public class Model {

    private String fileRubrica = "Rubrica.txt";
    private ArrayList<Contatto> rubrica = new ArrayList<>();
    private ArrayList<Contatto> rubricaPreferiti = new ArrayList<>();
    private ModelTabella modelTabella = new ModelTabella();

    // Metodo per aggiungere un contatto alla rubrica e alla tabella
    public void aggiungiContatto(Contatto contattoAdd) {
        rubrica.add(contattoAdd);
        modelTabella.aggiungiContatto(contattoAdd);
        aggiungiContattoFile(contattoAdd);
    }

    // Metodo per rimuovere un contatto dalla rubrica
    public void removeContatto(Contatto contattoDelete, JTable tabella) {
        for (int i = 0; i < rubrica.size(); i++) {
            if (contattoDelete.getNome().equals(rubrica.get(i).getNome())
                 && contattoDelete.getCognome().equals(rubrica.get(i).getCognome())) {
                rubrica.remove(i);
                tabella.revalidate();
                tabella.repaint();
                break;
            }
        }
    }

    // Metodo per ottenere la lista dei contatti
    public ArrayList<Contatto> getRubrica() {
        return rubrica;
    }

    // Metodo per ottenere il ModelTabella
    public ModelTabella getModelTabella() {
        return modelTabella;
    }

    // Metodo per salvare un contatto nel file di testo
    public void aggiungiContattoFile(Contatto c) {
        try (FileWriter fileOutput = new FileWriter(fileRubrica, true); PrintWriter fOut = new PrintWriter(fileOutput)) {

            fOut.print(c.getNome() + ";");
            fOut.print(c.getCognome() + ";");
            fOut.print(c.getRecapito() + ";");
            fOut.print(c.getEmail());
            fOut.println();
            
            fOut.flush();
        } catch (IOException e) {
            System.out.println("ERRORE durante la scrittura del file.");
            e.printStackTrace();
        }
    }

    public void scritturaFile() {
        try (FileWriter fileOutput = new FileWriter(fileRubrica, false); PrintWriter fOut = new PrintWriter(fileOutput)) {
            for (Contatto c : rubrica) {
                fOut.print(c.getNome() + ";");
                fOut.print(c.getCognome() + ";");
                fOut.print(c.getRecapito() + ";");
                fOut.print(c.getEmail());
                fOut.println();
            }
            fOut.flush();
        } catch (IOException e) {
            System.out.println("ERRORE durante la scrittura del file.");
            e.printStackTrace();
        }
    }

    // Metodo per caricare i contatti dal file nella rubrica e nella tabella
    public void caricaContattiArray() {
        try (FileReader fileInput = new FileReader(fileRubrica); BufferedReader fIn = new BufferedReader(fileInput)) {

            String riga;
            while ((riga = fIn.readLine()) != null) {
                StringTokenizer s = new StringTokenizer(riga, ";");

                String nome = s.hasMoreTokens() ? s.nextToken() : "";
                String cognome = s.hasMoreTokens() ? s.nextToken() : "";
                String recapito = s.hasMoreTokens() ? s.nextToken() : "N/D";
                String email = s.hasMoreTokens() ? s.nextToken() : "N/D";

                Contatto contattoAdd = new Contatto(nome, cognome, recapito, email);
                rubrica.add(contattoAdd);
            }

        } catch (FileNotFoundException e) {
            System.out.println("File non trovato, verrà creato automaticamente.");
        } catch (IOException e) {
            System.out.println("ERRORE durante la lettura del file.");
            e.printStackTrace();
        }
    }
}
