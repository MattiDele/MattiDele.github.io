package io.github.RubricaGUI.model;

import io.github.RubricaGUI.Contatto;
import javax.swing.table.DefaultTableModel;

public class ModelTabella extends DefaultTableModel {

    public ModelTabella() {
        super(new Object[][]{}, new String[]{"Nome", "Cognome", "Recapito", "Email"});
    }

    // Metodo per aggiungere un contatto alla tabella
    public void aggiungiContatto(Contatto contatto) {
        Object[] riga = {contatto.getNome(), contatto.getCognome(), contatto.getRecapito(), contatto.getEmail()};
        addRow(riga);
    }

    //metodo per aggiornare il contatto
    public void aggiornaContatto(int row) {
        fireTableRowsUpdated(row, row);
    }
    
    //rende le righe e colonne delle tabelle non modificabili 
    @Override
    public boolean isCellEditable(int row, int column) {
        return false;  // Rende tutte le celle non modificabili
    }

}
