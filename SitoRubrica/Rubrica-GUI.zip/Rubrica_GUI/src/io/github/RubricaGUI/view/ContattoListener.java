
package io.github.RubricaGUI.view;


public interface ContattoListener {
    public void contattoActionPerfomed();
  
}
