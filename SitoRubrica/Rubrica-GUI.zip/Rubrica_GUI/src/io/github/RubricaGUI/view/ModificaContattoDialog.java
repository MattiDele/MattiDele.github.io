package io.github.RubricaGUI.view;

import io.github.RubricaGUI.Contatto;
import io.github.RubricaGUI.model.Model;
import io.github.RubricaGUI.model.ModelTabella;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class ModificaContattoDialog extends javax.swing.JDialog {

    FrmPrincipale view = new FrmPrincipale();
    ModelTabella modelTabella = new ModelTabella();
    Model model = new Model();
    ContattoListener contattoListener;      
    

    public ModificaContattoDialog(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setLocationRelativeTo(null);
    }
    
    public void addContattoListener(ContattoListener contattoListener){
        this.contattoListener = contattoListener;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlNord = new javax.swing.JPanel();
        lblTitolo = new javax.swing.JLabel();
        mainPnl = new javax.swing.JPanel();
        pnlDestra = new javax.swing.JPanel();
        scrpContattiDaModificare = new javax.swing.JScrollPane();
        tblModificaContatti = new javax.swing.JTable();
        pnlSinistra = new javax.swing.JPanel();
        pnlSinistraSud = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        btnExit = new javax.swing.JButton();
        btnModifica = new javax.swing.JButton();
        pnlSinistraCenter = new javax.swing.JPanel();
        lblNome = new javax.swing.JLabel();
        txtNome = new javax.swing.JTextField();
        lblCognome = new javax.swing.JLabel();
        txtCognome = new javax.swing.JTextField();
        lblRecapito = new javax.swing.JLabel();
        txtRecapito = new javax.swing.JTextField();
        lblEmail = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        pnlNord.setBackground(new java.awt.Color(0, 172, 181));
        pnlNord.setPreferredSize(new java.awt.Dimension(388, 70));
        pnlNord.setLayout(new java.awt.BorderLayout());

        lblTitolo.setBackground(new java.awt.Color(0, 172, 181));
        lblTitolo.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        lblTitolo.setForeground(new java.awt.Color(255, 255, 255));
        lblTitolo.setText("                                      RUBRICA GUI");
        pnlNord.add(lblTitolo, java.awt.BorderLayout.CENTER);

        getContentPane().add(pnlNord, java.awt.BorderLayout.PAGE_START);

        mainPnl.setLayout(new java.awt.BorderLayout());

        pnlDestra.setPreferredSize(new java.awt.Dimension(600, 402));
        pnlDestra.setLayout(new java.awt.BorderLayout());

        scrpContattiDaModificare.setPreferredSize(new java.awt.Dimension(300, 100));

        tblModificaContatti.setModel(modelTabella);
        scrpContattiDaModificare.setViewportView(tblModificaContatti);

        pnlDestra.add(scrpContattiDaModificare, java.awt.BorderLayout.CENTER);

        mainPnl.add(pnlDestra, java.awt.BorderLayout.LINE_END);

        pnlSinistra.setLayout(new java.awt.BorderLayout());

        btnExit.setText("Exit");
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });
        jPanel1.add(btnExit);

        btnModifica.setText("Modifica");
        btnModifica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificaActionPerformed(evt);
            }
        });
        jPanel1.add(btnModifica);

        javax.swing.GroupLayout pnlSinistraSudLayout = new javax.swing.GroupLayout(pnlSinistraSud);
        pnlSinistraSud.setLayout(pnlSinistraSudLayout);
        pnlSinistraSudLayout.setHorizontalGroup(
            pnlSinistraSudLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlSinistraSudLayout.createSequentialGroup()
                .addContainerGap(155, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(108, 108, 108))
        );
        pnlSinistraSudLayout.setVerticalGroup(
            pnlSinistraSudLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlSinistraSudLayout.createSequentialGroup()
                .addContainerGap(19, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );

        pnlSinistra.add(pnlSinistraSud, java.awt.BorderLayout.PAGE_END);

        pnlSinistraCenter.setLayout(new java.awt.GridLayout(8, 1, 10, 10));

        lblNome.setText("Nome");
        lblNome.setEnabled(false);
        pnlSinistraCenter.add(lblNome);

        txtNome.setAutoscrolls(false);
        pnlSinistraCenter.add(txtNome);

        lblCognome.setText("Cognome");
        lblCognome.setEnabled(false);
        pnlSinistraCenter.add(lblCognome);

        txtCognome.setAutoscrolls(false);
        pnlSinistraCenter.add(txtCognome);

        lblRecapito.setText("Recapito");
        lblRecapito.setEnabled(false);
        pnlSinistraCenter.add(lblRecapito);

        txtRecapito.setAutoscrolls(false);
        pnlSinistraCenter.add(txtRecapito);

        lblEmail.setText("Email");
        lblEmail.setEnabled(false);
        pnlSinistraCenter.add(lblEmail);

        txtEmail.setAutoscrolls(false);
        pnlSinistraCenter.add(txtEmail);

        pnlSinistra.add(pnlSinistraCenter, java.awt.BorderLayout.CENTER);

        mainPnl.add(pnlSinistra, java.awt.BorderLayout.CENTER);

        getContentPane().add(mainPnl, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnModificaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificaActionPerformed
        contattoListener.contattoActionPerfomed();
    }//GEN-LAST:event_btnModificaActionPerformed

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
        dispose();
    }//GEN-LAST:event_btnExitActionPerformed

    public JTable getTblModificaContatti() {
        return tblModificaContatti;
    }
    
    public JTextField getTxtCognome() {
        return txtCognome;
    }

    public JTextField getTxtEmail() {
        return txtEmail;
    }

    public JTextField getTxtNome() {
        return txtNome;
    }

    public JTextField getTxtRecapito() {
        return txtRecapito;
    }
    
    public void clearTxt() {
        txtNome.setText("");
        txtCognome.setText("");
        txtRecapito.setText("");
        txtEmail.setText("");
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnExit;
    private javax.swing.JButton btnModifica;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblCognome;
    private javax.swing.JLabel lblEmail;
    private javax.swing.JLabel lblNome;
    private javax.swing.JLabel lblRecapito;
    private javax.swing.JLabel lblTitolo;
    private javax.swing.JPanel mainPnl;
    private javax.swing.JPanel pnlDestra;
    private javax.swing.JPanel pnlNord;
    private javax.swing.JPanel pnlSinistra;
    private javax.swing.JPanel pnlSinistraCenter;
    private javax.swing.JPanel pnlSinistraSud;
    private javax.swing.JScrollPane scrpContattiDaModificare;
    private javax.swing.JTable tblModificaContatti;
    private javax.swing.JTextField txtCognome;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtRecapito;
    // End of variables declaration//GEN-END:variables

    
    
    
    
}
